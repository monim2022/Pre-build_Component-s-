
# 🐞 BugHunterAlert Component

**BugHunterAlert** is a funny, reusable React component designed to make debugging fun. Great for personal projects, portfolios, and adding humor to any dev app.

## 🚀 Features
- Random funny bug messages and developer quotes
- Light/Dark mode support
- "Squash It" button with animated feedback
- Minimal styling with Tailwind-style simplicity (but no dependencies)

## 📦 Usage

```
import BugHunterAlert from './BugHunterAlert';
import './BugHunterAlert.css';

<BugHunterAlert theme="dark" />
```

## 📂 Files Included
- `BugHunterAlert.js`
- `BugHunterAlert.css`
- `demo.html` (live preview)
- `README.md`
