
// BugHunterAlert.js
import React, { useState } from 'react';
import './BugHunterAlert.css';

const bugMessages = [
  "Found 3 bugs hiding in line 42...",
  "This bug just called itself a feature.",
  "Segmentation Fault? More like Dev Frustration.",
  "Looks like your code needs therapy, not debugging."
];

const devRoasts = [
  "Maybe the real bug was you all along.",
  "Code like nobody is watching... and bugs will still show up.",
  "You miss 100% of the semicolons you don't place.",
  "Even ChatGPT can’t help you now."
];

function getRandomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

const BugHunterAlert = ({ theme = 'light', bugMessage, quote, onSquash }) => {
  const [squashed, setSquashed] = useState(false);

  const handleSquash = () => {
    setSquashed(true);
    if (onSquash) onSquash();
    setTimeout(() => setSquashed(false), 2000);
  };

  const styleTheme = theme === 'dark' ? 'bha-dark' : 'bha-light';

  return (
    <div className={`bug-hunter-alert ${styleTheme}`}>
      <div className="bug-message">{bugMessage || getRandomItem(bugMessages)}</div>
      <div className="bug-quote">💬 {quote || getRandomItem(devRoasts)}</div>
      <button className="squash-button" onClick={handleSquash}>
        {squashed ? "💥 Squashed!" : "🐞 Squash It"}
      </button>
    </div>
  );
};

export default BugHunterAlert;
